Tactile Sounds TS-808 
---------------------

The TS-808 is a software emulation (VSTi plugin) of the Roland TR-808. In 
(re)creating the sounds, I referred to the TR-808 service notes, which provide 
full schematics for each voice, and analysed the best samples I could find (The 
Tape808, by Goldbaby). Eric Archer, who has built hardware clones of various 808 
voices, was kind enough to help me calculate the frequencies of the square wave 
oscillators that are the basis of the CYmbal/HiHat sounds. I fine-tuned each 
voice until I felt that it sounded the way that an 808 fresh off the assembly 
line would have sounded in 1984, and then I added some useful mods. 

There are two versions of the TS-808: Mono and Stereo. Tactile Sounds recommends 
the Mono version for most purposes. The Stereo version was developed because 
some hosts send mono signals to the left channel only.

Author
------

Jonathan Murphy
http://tactilesounds.blogspot.com/

Credits
-------

GUI designed by Limeflavour
http://flavoursoflime.blogspot.com/

Payment
-------

The TS-808 is free (see "Licensing" below), however if you use it a lot, and 
especially if you derive an income from your use of it, please consider making a 
donation.

Installation
------------

Copy TS-808 Mono.dll and/or TS-808 Stereo.dll to the folder in which you store 
your VST plugins, typically something like 
C:/Program Files/Steinberg/Cubase/VstPlugins.

Licensing
---------

This work is licensed under the Creative Commons Attribution-Noncommercial-No 
Derivative Works 3.0 Australia License. 
To view a copy of this license, either
(a) visit http://creativecommons.org/licenses/by-nc-nd/2.5/au/; or 
(b) send a letter to Creative Commons, 171 2nd Street, Suite 300, San Francisco, 
California, 94105, USA.


About the Sounds
----------------

The MIDI notes that trigger the sounds are:

BD - 35, 36, 60
SD - 38, 40, 61
LT - 41, 43, 45, 68
MT - 47, 48, 69
HT - 50, 70
LC - 52, 71
MC - 53, 72
HC - 55, 73
RS - 51, 62
CL - 58, 64
CP - 39, 63
MA - 54, 75
CB - 56, 74
CY - 49, 57, 67
CH - 42, 65
OH - 46, 66

All Voices
----------

All voices have controls for Velocity, Level, and Output. TS-808 Stereo also has
Pan controls. Any voice can be routed to any of the 8 outputs. All voices have a 
red LED showing activity, and can be muted by turning off the green button.

Bass Drum
---------

The base frequency of the BD is 48.999 Hz, better known as G1 or MIDI note 31. 
Tune alters the pitch by up to +-12 semitones, ie a value of +2 will raise the 
base frequency of the BD by 2 semitones, to A1 (55 Hz). 

Snare Drum
----------

The base frequencies of the SD tone generators are 174.614 Hz (F3) and 349.228 
Hz (F4). Tune alters the pitch of the tone generators by up to +-12 semitones.

Toms
----

The base frequencies of the toms are:
LT - 97.999 Hz (G2)
MT - 146.832 Hz (D3)
HT - 220 Hz (A3)
The Tune parameters alter the pitch by up to +-3 semitones.
The Reverb parameters control the amount of pink noise mixed with the signal.

Congas
------

The base frequencies of the congas are:
LC - 195.997 Hz (G3)
MC - 293.664 Hz (D4)
HC - 440 Hz (A4)
The Tune parameters alter the pitch by up to +-3 semitones.
The Decay parameters extend or reduce the decay time of the signal.

Rim Shot
--------

There are two tone generators for the RS. The signals are half-wave rectified. 
The rectified signal is mixed with the clean signal. Tone controls the mix. At 
-5 only the rectified signal is present, at 5 only the clean signal. At 0 the 
mix is equal and the sound is very close to that of the TR-808.

CLave
-----

The base frequency of the CL is 2349.318 Hz (D7). Tune alters the pitch by up to 
+-6 semitones.

ClaP
----

The CP is composed of a strike portion and a reverb portion. Rev Level controls 
the amount of the reverb portion present in the mix. Decay and Rev Decay control 
the decay times of the strike and reverb portions respectively.
 
MAraca
------

The MA is just bandpass filtered white noise shaped by an envelope. Tune varies 
the frequency of the band pass filter from around 350Hz to 10500 Hz. Attack & 
Decay control the envelope generator. When all controls are at 10 the sound is 
all but identical to that of the TR-808. 

Cow Bell
--------

The CB comprises two half-wave rectified square waves run through a bandpass 
filter. According to the schematics, the frequencies are 540 Hz and 800 Hz. In 
the samples I analysed, they were closer to 565 Hz and 849 Hz. I settled on base 
frequencies of 523.251 Hz and 783.991 Hz - a perfect fifth, and in tune with the 
rest of the voices. Tune alters these pitches by up to +-12 semitones. Buzz 
controls the amount of the rectified signal in the final mix, and Clang controls 
the amount by which the oscillators are detuned. 

Hi Hats
-------

The CH and OH of the TR-808 have different envelopes and filters. In the TS-808 
the envelopes are different but the filter is shared. Tune varies the cutoff 
frequency of the filter, from ~8000 Hz to ~11000 Hz. Decay controls the decay 
time of the OH. 