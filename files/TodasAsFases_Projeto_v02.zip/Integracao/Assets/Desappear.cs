﻿using UnityEngine;
using System.Collections;

public class Desappear : MonoBehaviour {
	public GameObject Key;
	void OnTriggerEnter2D(Collider2D other){
		if (other.gameObject.tag == "Player")
			Key.SetActive (false);
	}
}
