using UnityEngine;
using System.Collections;


public enum GoTweenState
{
	Running,
	Paused,
	Complete,
	Destroyed
}
