using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class SceneNamer : MonoBehaviour
{
	private Text txt;

	void Start()
	{
		txt = GetComponent<Text>();
		DontDestroyOnLoad(transform.parent.gameObject);
	}

	void Update()
	{
		txt.text = "FASE: " + SceneManager.GetActiveScene().name;
		if (Input.GetKeyDown(KeyCode.K))
		{
			SceneManager.LoadScene(GetScene(0));  
		}

		if (Input.GetKeyDown(KeyCode.L))
		{
			SceneManager.LoadScene(GetScene(1));  
		}

		if (Input.GetKeyDown(KeyCode.J))
		{
			SceneManager.LoadScene(GetScene(-1));  
		}

		if (Input.GetKeyDown(KeyCode.Escape))
		{
			Application.Quit();  
		}
	}

	int GetScene(int change)
	{
		if (SceneManager.GetActiveScene().buildIndex + change >= SceneManager.sceneCountInBuildSettings ||
		    SceneManager.GetActiveScene().buildIndex + change < 0)
		{
			return 0;
		}
		return SceneManager.GetActiveScene().buildIndex + change;
	}
}
