﻿using UnityEngine;
using System.Collections;

public class Red_Buttons : MonoBehaviour {
	public int ID;
	public GameObject Red;
	public bool block_red_Active = false;
	
	// Update is called once per frame
	void Update () {
		if (block_red_Active == false) {
			Red.SetActive (false);
		}
		else if (block_red_Active == true){
			Red.SetActive (true);
		}
	}

	void OnTriggerStay2D(Collider2D other){
		Debug.Log ("HELLO");
		if (other.gameObject.tag == "Player" && Input.GetKeyDown(KeyCode.Return)) {

			if (ID == 1) {
				Debug.Log ("RED");
				block_red_Active = !block_red_Active;
			}
		}// get enter button
	}
}
