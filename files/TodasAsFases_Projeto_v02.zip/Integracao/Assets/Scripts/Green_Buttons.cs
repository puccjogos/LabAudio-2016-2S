﻿using UnityEngine;
using System.Collections;

public class Green_Buttons : MonoBehaviour {
	public int ID;
	public GameObject Green;
	public bool block_green_Active = false;
	void Update(){
		
		if (block_green_Active == false) {
			Green.SetActive (false);
		}
		else if(block_green_Active == true){
			Green.SetActive (true);
		}
	}
	void OnTriggerStay2D(Collider2D other){
		Debug.Log ("HELLO");
		if (other.gameObject.tag == "Player" && Input.GetKeyDown(KeyCode.Return)) {

			if (ID == 2) {
				Debug.Log ("GREEN");
				block_green_Active = !block_green_Active;
			}
		}// get enter button
	}
}
