/* This class is now legacy. Keep the definition here for the migration script to work */

using UnityEngine;
public class FMODAsset : ScriptableObject
{
	public string path;
	public string id; 
};
